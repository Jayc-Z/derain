import os
import re
#coding=utf-8
"""批量修改文件夹的图片名"""

def ReFigName(dirPath, label):
      ####param dirPath: 文件夹路径
    # 对目录下的文件进行遍历
    for file in sorted(os.listdir(dirPath)):
        # 判断是否是文件
        if str.endswith(os.path.join(dirPath, file), ".png"):
            id = file.split("-")[1].split("x")[0] if "x" in file else file.split("-")[1].split(".")[0]
            newfile = label + "_" + str(id) + ".png"##在此处修改自己想要的图片名即可
            print(newfile)
            # 重命名
            os.rename(os.path.join(dirPath, file), os.path.join(dirPath, newfile))
    print("***修改成功***")

def forloop_root_path(root_path):
    for dir in os.listdir(root_path):
        if dir in ["train", "test"]:
            for label in os.listdir(os.path.join(root_path, dir)):
                if label in ["norain", "rain"]:
                    dir_path = os.path.join(root_path, dir, label)
                    return dir_path, label

if __name__ == '__main__':
    root_path = "Rain200L"###添加自己的文件路径即可
    dir_path, label = forloop_root_path(root_path)
    ReFigName(dir_path, label)


