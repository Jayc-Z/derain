### put checkpoint here
 - gena.pth.tar   # 雨转无雨
 - genb.pth.tar   # 无雨转雨

